// Dummy class to group shared resources

namespace AdvancedProgramming_Lesson2
{
    public class SharedResource
    {
    }
}